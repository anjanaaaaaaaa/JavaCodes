package com.anjanacodes;

public class PasswordEvent extends AbstractEvent{


    public PasswordEvent (String id){
        super(id);

    }
    @Override
    public void process(){
        System.out.println("Customer "+ id+ "Changed their password");
    }
}
