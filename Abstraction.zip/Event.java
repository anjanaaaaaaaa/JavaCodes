package com.anjanacodes;

public interface Event {
    long getTimeStamp();
    void process();
}
