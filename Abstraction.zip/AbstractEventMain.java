package com.anjanacodes;

public class AbstractEventMain {
    public static void main(String[] args)
    {
        PasswordEvent pw = new PasswordEvent("2133323");
        pw.getTimeStamp();
        pw.process();

    }
}
