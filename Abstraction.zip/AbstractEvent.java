package com.anjanacodes;

import java.sql.Timestamp;

public  abstract class AbstractEvent implements Event {
    protected Long createTimeStamp;
    protected String id;
    public AbstractEvent(String id){
        this.createTimeStamp = new Timestamp(System.currentTimeMillis()).getTime();
        this.id = id;

    }

    @Override
    public long getTimeStamp() {
        return this.createTimeStamp;
    }
    public abstract void process();
}
